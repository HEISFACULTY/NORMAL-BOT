Const = {menu}
Const = {commands}
const = {mp3song}
const = {wachannel}

('Remote git from ibrahim.mgtyu')

{'Full copy from remote git menu'}

export text message, audio, link, url

